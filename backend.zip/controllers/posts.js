const Post = require("../models/post");

exports.addComment = async (req, res, next) => {
  const comments = [...req.body.comments, req.body.newComment]
  Post.updateOne(
    { _id: req.params.id },
    {
      $set: {
        comments: comments
      }
    })
    .then(result => {
      if (result.n > 0) {
        res.status(200).json({ message: "Comment added!", comments: comments });
      } else {
        res.status(401).json({ message: "Not authorized!" });
      }
    })
    .catch(error => {
      res.status(500).json({
        message: "Couldn't add comment!"
      });
    });

}

exports.addKeep = async (req, res, next) => {
  const userKeepsIDs = [...req.body.userKeepsIDs, req.user.id];
  Post.updateOne(
    { _id: req.params.id },
    {
      $set: {
        userKeepsIDs: userKeepsIDs
      }
    })
    .then(result => {
      if (result.n > 0) {
        res.status(200).json({ message: "keep counted!" });
      } else {
        res.status(401).json({ message: "Not authorized!" });
      }
    })
    .catch(error => {
      res.status(500).json({
        message: "Couldn't add keep!"
      });
    });

};

exports.deleteKeep = (req, res, next) => {
  let userKeepsIDs = [...req.body.userKeepsIDs];
  userKeepsIDs = userKeepsIDs.filter(item => item !== req.user.id);

  Post.updateOne(
    { _id: req.params.id },
    {
      $set: {
        userKeepsIDs: userKeepsIDs
      }
    })
    .then(result => {
      if (result.n > 0) {
        res.status(200).json({ message: "keep deleted!" });
      } else {
        res.status(401).json({ message: "Not authorized!" });
      }
    })
    .catch(error => {
      res.status(500).json({
        message: "Couldn't add keep!"
      });
    });

};

exports.postVote = (req, res, next) => {
  const voters = [...req.body.votes, req.user.id]
  Post.updateOne(
    { _id: req.params.id },
    {
      $set: {
        votes: voters
      }
    })
    .then(result => {
      if (result.n > 0) {
        res.status(200).json({ message: "Vote counted!", votes: voters });
      } else {
        res.status(401).json({ message: "Not authorized!" });
      }
    })
    .catch(error => {
      res.status(500).json({
        message: "Couldn't update post!"
      });
    });
};

exports.createPost = (req, res, next) => {
  const url = req.protocol + "://" + req.get("host");
  const post = new Post({
    title: req.body.title,
    description: req.body.description,
    imagePath: url + "/images/" + req.file.filename,
    creator: req.user.id,
    creatorName: req.body.creatorName,
    profileImage: req.body.profileImage,
  });
  post
    .save()
    .then(createdPost => {
      res.status(201).json({
        message: "Post added successfully",
        post: {
          ...createdPost,
          id: createdPost._id
        }
      });
    })
    .catch(error => {
      res.status(500).json({
        message: "Creating a post failed!"
      });
    });
};

exports.updatePost = (req, res, next) => {
  let imagePath = req.body.imagePath;
  if (req.file) {
    const url = req.protocol + "://" + req.get("host");
    imagePath = url + "/images/" + req.file.filename;
  }

  Post.updateOne({ _id: req.params.id, creator: req.user.id }, {
    $currentDate: {
      lastModified: true,
      "cancellation.date": { $type: "timestamp" }
    },
    $set: {
      title: req.body.title,
      description: req.body.description,
      imagePath: imagePath,
      "cancellation.reason": "user request",
      status: "D"
    }
  })
    .then(result => {
      if (result.n > 0) {
        res.status(200).json({
          message: "Update successful!", post: {
            title: req.body.title,
            description: req.body.description,
            imagePath: imagePath
          }
        });
      } else {
        res.status(401).json({ message: "Not authorized!" });
      }
    })
    .catch(error => {
      res.status(500).json({
        message: "Couldn't update post!"
      });
    });
};

exports.getPosts = async (req, res, next) => {
  const allPosts = await Post.find();
  if (!allPosts) return res.status(400).send({ message: "Posts not fetched" });

  res.status(200).json({
    message: "Posts fetched successfully!",
    posts: allPosts
  });
};

exports.getPost = (req, res, next) => {
  Post.findById(req.params.id)
    .then(post => {
      if (post) {
        res.status(200).json(post);
      } else {
        res.status(404).json({ message: "Post not found!" });
      }
    })
    .catch(error => {
      res.status(500).json({
        message: "Fetching post failed!"
      });
    });
};

exports.deletePost = (req, res, next) => {
  Post.deleteOne({ _id: req.params.id, creator: req.user.id })
    .then(result => {
      console.log(result);
      if (result.n > 0) {
        res.status(200).json({ message: "Deletion successful!" });
      } else {
        res.status(401).json({ message: "Not authorized!" });
      }
    })
    .catch(error => {
      res.status(500).json({
        message: "Deleting posts failed!"
      });
    });
};