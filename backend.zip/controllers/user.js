const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const User = require("../models/user");

const { signupValidation, loginValidation } = require('../middleware/validation');


exports.createUser = async (req, res, next) => {

  const { error } = signupValidation(req.body);
  if (error) return res.status(400).send({ message: error.details[0].message });

  const emailExist = await User.findOne({ email: req.body.email });
  if (emailExist) return res.status(400).send({ message: "Email already Exist" });

  const salt = await bcrypt.genSalt(10);
  const hashedPassword = await bcrypt.hash(req.body.password, salt);

  const url = req.protocol + "://" + req.get("host");
  const user = new User({
    name: req.body.name,
    email: req.body.email,
    password: hashedPassword,
    image: url + "/images/" + req.file.filename
  });

  try {
    const token = jwt.sign({ id: user._id }, "TOPSECRET");
    if (!token) return res.status(400).send({ message: "No token" });
    const savedUser = await user.save();
    res.status(200).send({ token: token, id: user._id, name: user.name, profileImage: user.image, email: user.email })
  }
  catch (err) {
    res.status(400).json({ message: err.message })
  }

};

exports.userLogin = async (req, res, next) => {

  const { error } = loginValidation(req.body);
  if (error) return res.status(400).send({ message: error.details[0].message });

  const user = await User.findOne({ email: req.body.email });
  if (!user) return res.status(400).send({ message: "Wrong email" });

  const validPass = await bcrypt.compare(req.body.password, user.password);
  if (!validPass) return res.status(400).send({ message: "Wrong password" });

  const token = jwt.sign({ id: user._id }, "TOPSECRET");
  if (!token) return res.status(400).send({ message: "No token" });

  res.status(200).send({ token: token, id: user._id, name: user.name, profileImage: user.image, email: user.email, keeps: user.keeps })
};

// exports.updateUser = (req, res, next) => {
//   let imagePath = req.body.imagePath;
//   if (req.file) {
//     const url = req.protocol + "://" + req.get("host");
//     imagePath = url + "/images/" + req.file.filename;
//   }
//   User.updateOne({ _id: req.params.id, creator: req.user.id }, {
//     $currentDate: {
//       lastModified: true,
//       "cancellation.date": { $type: "timestamp" }
//     },
//     $set: {
//       imagePath: imagePath,
//       "cancellation.reason": "user request",
//       status: "D"
//     }
//   })
//     .then(result => {
//       if (result.n > 0) {
//         res.status(200).json({
//           message: "Update successful!", 
//           user: {
//             imagePath: imagePath
//           }
//         });
//       } else {
//         res.status(401).json({ message: "Not authorized!" });
//       }
//     })
//     .catch(error => {
//       res.status(500).json({
//         message: "Couldn't update user image!"
//       });
//     });
// };

// exports.getUser = (req, res, next) => {
//   User.findById(req.params.id)
//     .then(user => {
//       if (user) {
//         res.status(200).json(user);
//       } else {
//         res.status(404).json({ message: "User not found!" });
//       }
//     })
//     .catch(error => {
//       res.status(500).json({
//         message: "Fetching user failed!"
//       });
//     });
// };