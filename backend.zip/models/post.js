const mongoose = require("mongoose");


const postSchema = mongoose.Schema({
  title: { type: String, required: true },
  description: { type: String, required: true },
  imagePath: { type: String, required: true },
  creator: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  date: { type: Date, default: Date.now },
  lastModified: { type: Date },
  creatorName: { type: String },
  profileImage: { type: String, required: true },
  votes: { type: [ String ]  },
  userKeepsIDs: { type: [ String ]  },
  comments: { type: [ Object ] }
});

module.exports = mongoose.model("Posts", postSchema);
