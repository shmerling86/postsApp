const Joi = require('@hapi/joi');

const signupValidation = (data) => {
    const schema = Joi.object({
        name: Joi.string().min(6).max(10).required(),
        email: Joi.string().required().email(),
        password: Joi.string().min(6).max(15).required(),
    });
    return schema.validate(data);
}

const loginValidation = (data) => {
    const schema = Joi.object({
        email: Joi.string().required().email(),
        password: Joi.string().min(6).max(15).required()
    });
    return schema.validate(data);
}

module.exports.signupValidation = signupValidation;
module.exports.loginValidation = loginValidation;